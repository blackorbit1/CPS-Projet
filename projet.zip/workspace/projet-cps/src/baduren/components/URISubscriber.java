package baduren.components;

public class URISubscriber {

}

package baduren.components;

public class URIPublisher {

}

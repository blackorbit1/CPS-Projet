package baduren.interfaces;

public interface MessageFilterI {
	boolean filter(MessageI m)throws Exception;; 
}
